import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as CalendarDays, i as ChevronDown, n as Sun, o as Cake, r as Moon } from "../_libs/lucide-react.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as addMonths } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Nu90mUGi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium outline-none transition-[scale,background-color,box-shadow,color] duration-150 ease-out disabled:pointer-events-none disabled:opacity-50 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg shadow-card hover:bg-biscuit-deep",
			secondary: "bg-biscuit text-fg hover:bg-biscuit-deep",
			ghost: "bg-transparent text-fg hover:bg-biscuit",
			outline: "bg-surface text-fg shadow-card hover:bg-surface-warm"
		},
		size: {
			default: "h-11 px-5",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-6 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		ref,
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
});
Button.displayName = "Button";
var translations = {
	en: {
		appName: "Age",
		appNameFull: "Age Calculator",
		kicker: "Age & birthday",
		title: "Your age, to the day.",
		tagline: "Measure years in the Gregorian or Hijri calendar, then watch a live countdown to your next birthday.",
		today: "Today",
		language: "Language",
		langAr: "العربية",
		langEn: "EN",
		gregorian: "Gregorian",
		hijri: "Hijri",
		hijriHint: "Umm al-Qura calendar",
		dob: "Date of birth",
		day: "Day",
		month: "Month",
		year: "Year",
		calculate: "Calculate age",
		yourAge: "Your age",
		years: "Years",
		months: "Months",
		days: "Days",
		hours: "Hours",
		minutes: "Minutes",
		seconds: "Seconds",
		countdownTitle: "Until your next birthday",
		happyBirthday: "Happy birthday",
		happyBirthdayBody: "Today is yours. The next year starts counting from midnight.",
		equivalent: "In the other calendar",
		bornOn: "Born on",
		emptyHint: "Choose a calendar, enter your date of birth, and see your exact age with a ticking countdown.",
		errorFuture: "Date of birth cannot be in the future.",
		errorInvalid: "This date does not exist in the selected calendar.",
		errorIncomplete: "Please choose day, month, and year.",
		footer: "Hijri dates follow the Umm al-Qura calendar used in Saudi Arabia.",
		switchTo: "Switch language",
		selectDay: "Day",
		selectMonth: "Month",
		selectYear: "Year"
	},
	ar: {
		appName: "العمر",
		appNameFull: "حاسبة العمر",
		kicker: "العمر وعيد الميلاد",
		title: "عمرك، إلى اليوم.",
		tagline: "احسب عمرك بالميلادي أو الهجري وفق تقويم أم القرى، وتابع العد التنازلي الحيّ حتى عيد ميلادك القادم.",
		today: "اليوم",
		language: "اللغة",
		langAr: "العربية",
		langEn: "EN",
		gregorian: "ميلادي",
		hijri: "هجري",
		hijriHint: "تقويم أم القرى",
		dob: "تاريخ الميلاد",
		day: "اليوم",
		month: "الشهر",
		year: "السنة",
		calculate: "احسب العمر",
		yourAge: "عمرك",
		years: "سنوات",
		months: "أشهر",
		days: "أيام",
		hours: "ساعات",
		minutes: "دقائق",
		seconds: "ثوانٍ",
		countdownTitle: "حتى عيد ميلادك القادم",
		happyBirthday: "عيد ميلاد سعيد",
		happyBirthdayBody: "اليوم يومك. يبدأ العد للسنة القادمة من منتصف الليل.",
		equivalent: "في التقويم الآخر",
		bornOn: "وُلدت في",
		emptyHint: "اختر التقويم، أدخل تاريخ ميلادك، واطّلع على عمرك بدقة مع عدّ تنازلي يتحرّك كل ثانية.",
		errorFuture: "لا يمكن أن يكون تاريخ الميلاد في المستقبل.",
		errorInvalid: "هذا التاريخ غير موجود في التقويم المختار.",
		errorIncomplete: "يرجى اختيار اليوم والشهر والسنة.",
		footer: "التواريخ الهجرية وفق تقويم أم القرى المعتمد في المملكة العربية السعودية.",
		switchTo: "تبديل اللغة",
		selectDay: "اليوم",
		selectMonth: "الشهر",
		selectYear: "السنة"
	}
};
var GREGORIAN_MONTHS = {
	en: [
		"January",
		"February",
		"March",
		"April",
		"May",
		"June",
		"July",
		"August",
		"September",
		"October",
		"November",
		"December"
	],
	ar: [
		"يناير",
		"فبراير",
		"مارس",
		"أبريل",
		"مايو",
		"يونيو",
		"يوليو",
		"أغسطس",
		"سبتمبر",
		"أكتوبر",
		"نوفمبر",
		"ديسمبر"
	]
};
var HIJRI_MONTHS = {
	en: [
		"Muharram",
		"Safar",
		"Rabiʿ al-Awwal",
		"Rabiʿ al-Thani",
		"Jumada al-Ula",
		"Jumada al-Thania",
		"Rajab",
		"Shaʿban",
		"Ramadan",
		"Shawwal",
		"Dhu al-Qaʿdah",
		"Dhu al-Hijjah"
	],
	ar: [
		"محرم",
		"صفر",
		"ربيع الأول",
		"ربيع الآخر",
		"جمادى الأولى",
		"جمادى الآخرة",
		"رجب",
		"شعبان",
		"رمضان",
		"شوال",
		"ذو القعدة",
		"ذو الحجة"
	]
};
var ARABIC_DIGITS = [
	"٠",
	"١",
	"٢",
	"٣",
	"٤",
	"٥",
	"٦",
	"٧",
	"٨",
	"٩"
];
function formatNumber(n, lang) {
	const s = String(Math.trunc(n));
	if (lang !== "ar") return s;
	return s.replace(/\d/g, (d) => ARABIC_DIGITS[Number(d)] ?? d);
}
var LANG_STORAGE_KEY = "age-calc-lang";
var HIJRI_MIN_YEAR = 1343;
var HIJRI_MAX_YEAR = 1500;
function utcNoon(year, month, day) {
	return new Date(Date.UTC(year, month - 1, day, 12, 0, 0));
}
function utcYMD(date) {
	return {
		year: date.getUTCFullYear(),
		month: date.getUTCMonth() + 1,
		day: date.getUTCDate()
	};
}
function hijriPartsFromDate(date) {
	const parts = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura", {
		year: "numeric",
		month: "numeric",
		day: "numeric",
		timeZone: "UTC"
	}).formatToParts(date);
	const num = (type) => {
		const raw = parts.find((p) => p.type === type)?.value ?? "0";
		return Number.parseInt(raw.replace(/[^\d]/g, ""), 10) || 0;
	};
	return {
		year: num("year"),
		month: num("month"),
		day: num("day")
	};
}
function gregorianToHijri(g) {
	return hijriPartsFromDate(utcNoon(g.year, g.month, g.day));
}
function hijriToGregorian(h) {
	const estimateDays = Math.floor((h.year - 1) * 354.36708) + Math.floor((h.month - 1) * 29.530588) + (h.day - 1);
	let date = new Date(Date.UTC(622, 6, 19, 12, 0, 0) + estimateDays * 864e5);
	for (let i = 0; i < 16; i++) {
		const current = hijriPartsFromDate(date);
		const delta = (h.year - current.year) * 354 + (h.month - current.month) * 29 + (h.day - current.day);
		if (delta === 0) return utcYMD(date);
		date = new Date(date.getTime() + delta * 864e5);
	}
	return utcYMD(date);
}
function isValidGregorian(g) {
	if (g.month < 1 || g.month > 12 || g.day < 1 || g.day > 31) return false;
	const dt = new Date(g.year, g.month - 1, g.day);
	return dt.getFullYear() === g.year && dt.getMonth() === g.month - 1 && dt.getDate() === g.day;
}
function isValidHijri(h) {
	if (h.year < HIJRI_MIN_YEAR || h.year > HIJRI_MAX_YEAR) return false;
	if (h.month < 1 || h.month > 12 || h.day < 1 || h.day > 30) return false;
	const back = gregorianToHijri(hijriToGregorian(h));
	return back.year === h.year && back.month === h.month && back.day === h.day;
}
function gregorianDaysInMonth(year, month) {
	return new Date(year, month, 0).getDate();
}
function hijriDaysInMonth(year, month) {
	const start = hijriToGregorian({
		year,
		month,
		day: 1
	});
	const startDate = utcNoon(start.year, start.month, start.day);
	const h = hijriPartsFromDate(new Date(startDate.getTime() + 25056e5));
	return h.year === year && h.month === month ? 30 : 29;
}
function daysInMonth(calendar, year, month) {
	if (!year || !month) return 31;
	return calendar === "hijri" ? hijriDaysInMonth(year, month) : gregorianDaysInMonth(year, month);
}
function localYMD(date) {
	return {
		year: date.getFullYear(),
		month: date.getMonth() + 1,
		day: date.getDate()
	};
}
function ymdToLocalDate(ymd, hours = 0, minutes = 0, seconds = 0) {
	return new Date(ymd.year, ymd.month - 1, ymd.day, hours, minutes, seconds);
}
function compareYMD(a, b) {
	return a.year - b.year || a.month - b.month || a.day - b.day;
}
function calendarDiff(birth, now, monthLength) {
	let years = now.year - birth.year;
	let months = now.month - birth.month;
	let days = now.day - birth.day;
	if (days < 0) {
		months -= 1;
		const prevMonth = now.month === 1 ? 12 : now.month - 1;
		const prevYear = now.month === 1 ? now.year - 1 : now.year;
		days += monthLength(prevYear, prevMonth);
	}
	if (months < 0) {
		years -= 1;
		months += 12;
	}
	return {
		years: Math.max(0, years),
		months: Math.max(0, months),
		days: Math.max(0, days)
	};
}
function convertYMD(ymd, from, to) {
	if (from === to) return ymd;
	return from === "gregorian" ? gregorianToHijri(ymd) : hijriToGregorian(ymd);
}
function yearRange(calendar, today) {
	if (calendar === "hijri") return {
		min: HIJRI_MIN_YEAR,
		max: gregorianToHijri(localYMD(today)).year
	};
	return {
		min: 1925,
		max: today.getFullYear()
	};
}
function formatYMD(ymd, lang, calendar) {
	const monthName = (calendar === "hijri" ? HIJRI_MONTHS[lang] : GREGORIAN_MONTHS[lang])[ymd.month - 1] ?? "";
	return `${formatNumber(ymd.day, lang)} ${monthName} ${formatNumber(ymd.year, lang)}${calendar === "hijri" ? lang === "ar" ? " هـ" : " AH" : ""}`;
}
function nextBirthdayYMD(birth, today, calendar) {
	const monthLength = calendar === "hijri" ? hijriDaysInMonth : gregorianDaysInMonth;
	const clampedDay = Math.min(birth.day, monthLength(today.year, birth.month));
	let candidate = {
		year: today.year,
		month: birth.month,
		day: clampedDay
	};
	if (compareYMD(candidate, today) < 0) {
		const year = today.year + 1;
		candidate = {
			year,
			month: birth.month,
			day: Math.min(birth.day, monthLength(year, birth.month))
		};
	}
	return {
		next: candidate,
		isToday: candidate.year === today.year && compareYMD(candidate, today) === 0
	};
}
function nextBirthdayDate(birth, now, calendar) {
	const todayGregorian = localYMD(now);
	const { next, isToday } = nextBirthdayYMD(birth, calendar === "hijri" ? gregorianToHijri(todayGregorian) : todayGregorian, calendar);
	let target = ymdToLocalDate(calendar === "hijri" ? hijriToGregorian(next) : next, 0, 0, 0);
	if (isToday) {
		const followingYear = {
			...next,
			year: next.year + 1
		};
		const monthLength = calendar === "hijri" ? hijriDaysInMonth : gregorianDaysInMonth;
		followingYear.day = Math.min(birth.day, monthLength(followingYear.year, followingYear.month));
		target = ymdToLocalDate(calendar === "hijri" ? hijriToGregorian(followingYear) : followingYear, 0, 0, 0);
	}
	return {
		target,
		isToday
	};
}
function countdownParts(now, target) {
	if (target.getTime() <= now.getTime()) return {
		months: 0,
		days: 0,
		hours: 0,
		minutes: 0,
		seconds: 0
	};
	let months = 0;
	let cursor = now;
	while (true) {
		const probe = addMonths(cursor, 1);
		if (probe.getTime() <= target.getTime()) {
			months += 1;
			cursor = probe;
		} else break;
		if (months > 24) break;
	}
	let remaining = Math.max(0, target.getTime() - cursor.getTime());
	const days = Math.floor(remaining / 864e5);
	remaining -= days * 864e5;
	const hours = Math.floor(remaining / 36e5);
	remaining -= hours * 36e5;
	const minutes = Math.floor(remaining / 6e4);
	remaining -= minutes * 6e4;
	const seconds = Math.floor(remaining / 1e3);
	return {
		months,
		days,
		hours,
		minutes,
		seconds
	};
}
function readStoredLang() {
	if (typeof window === "undefined") return "ar";
	const stored = window.localStorage.getItem(LANG_STORAGE_KEY);
	return stored === "en" || stored === "ar" ? stored : "ar";
}
function AgeCalculator() {
	const [lang, setLang] = (0, import_react.useState)("ar");
	const [calendar, setCalendar] = (0, import_react.useState)("gregorian");
	const [day, setDay] = (0, import_react.useState)(0);
	const [month, setMonth] = (0, import_react.useState)(0);
	const [year, setYear] = (0, import_react.useState)(0);
	const [error, setError] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	const [now, setNow] = (0, import_react.useState)(null);
	const resultsRef = (0, import_react.useRef)(null);
	const shouldScroll = (0, import_react.useRef)(false);
	const t = translations[lang];
	(0, import_react.useEffect)(() => {
		const stored = readStoredLang();
		if (stored !== lang) setLang(stored);
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang;
		document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
		document.title = t.appNameFull;
	}, [lang, t.appNameFull]);
	(0, import_react.useEffect)(() => {
		const tick = () => setNow(/* @__PURE__ */ new Date());
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	const todayG = now ? localYMD(now) : null;
	const todayH = todayG ? gregorianToHijri(todayG) : null;
	const years = now ? yearRange(calendar, now) : {
		min: 1925,
		max: 2026
	};
	const monthNames = calendar === "hijri" ? HIJRI_MONTHS[lang] : GREGORIAN_MONTHS[lang];
	const maxDay = daysInMonth(calendar, year, month);
	(0, import_react.useEffect)(() => {
		if (day && month && year && day > maxDay) setDay(maxDay);
	}, [
		day,
		month,
		year,
		maxDay
	]);
	(0, import_react.useEffect)(() => {
		if (!shouldScroll.current || !resultsRef.current) return;
		shouldScroll.current = false;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		resultsRef.current.scrollIntoView({
			behavior: reduce ? "auto" : "smooth",
			block: "start"
		});
	}, [result]);
	const derived = (0, import_react.useMemo)(() => {
		if (!result || !now) return null;
		const todayGregorian = localYMD(now);
		const todayInCal = result.calendar === "hijri" ? gregorianToHijri(todayGregorian) : todayGregorian;
		const monthLength = result.calendar === "hijri" ? hijriDaysInMonth : gregorianDaysInMonth;
		const age = calendarDiff(result.birth, todayInCal, monthLength);
		const otherCal = result.calendar === "hijri" ? "gregorian" : "hijri";
		const equivalent = convertYMD(result.birth, result.calendar, otherCal);
		const { target, isToday } = nextBirthdayDate(result.birth, now, result.calendar);
		return {
			age,
			equivalent,
			otherCal,
			isToday,
			count: countdownParts(now, target)
		};
	}, [result, now]);
	function switchCalendar(next) {
		if (next === calendar) return;
		if (day && month && year) {
			const converted = convertYMD({
				year,
				month,
				day
			}, calendar, next);
			setYear(converted.year);
			setMonth(converted.month);
			setDay(converted.day);
			if (result) setResult({
				birth: converted,
				calendar: next
			});
		} else if (result) {
			const converted = convertYMD(result.birth, result.calendar, next);
			setResult({
				birth: converted,
				calendar: next
			});
		}
		setCalendar(next);
		setError(null);
	}
	function handleCalculate(event) {
		event.preventDefault();
		if (!day || !month || !year) {
			setError(t.errorIncomplete);
			return;
		}
		const birth = {
			year,
			month,
			day
		};
		if (!(calendar === "hijri" ? isValidHijri(birth) : isValidGregorian(birth))) {
			setError(t.errorInvalid);
			return;
		}
		const todayGregorian = localYMD(now ?? /* @__PURE__ */ new Date());
		if (compareYMD(birth, calendar === "hijri" ? gregorianToHijri(todayGregorian) : todayGregorian) > 0) {
			setError(t.errorFuture);
			return;
		}
		setError(null);
		shouldScroll.current = true;
		setResult({
			birth,
			calendar
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 bg-biscuit-deep" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 bg-bg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-2xl items-center justify-between px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "leading-tight",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold tracking-tight",
								children: t.appName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: t.appNameFull
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageToggle, {
						lang,
						t,
						onChange: (next) => {
							setLang(next);
							window.localStorage.setItem(LANG_STORAGE_KEY, next);
						}
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full max-w-2xl flex-col gap-6 px-4 pb-16 pt-8 sm:pt-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-widest text-muted",
								children: t.kicker
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "max-w-xl text-4xl font-semibold leading-tight tracking-tight sm:text-5xl",
								children: t.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-lg text-base leading-normal text-muted",
								children: t.tagline
							}),
							todayG && todayH ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2 pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayChip, {
									label: t.gregorian,
									value: formatYMD(todayG, lang, "gregorian")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayChip, {
									label: t.hijri,
									value: formatYMD(todayH, lang, "hijri")
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-9 w-64 rounded-md bg-surface-warm" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "rounded-2xl bg-surface p-6 shadow-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "flex flex-col gap-5",
							onSubmit: handleCalculate,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarTabs, {
										calendar,
										t,
										onChange: switchCalendar
									}), calendar === "hijri" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "px-1 text-xs text-subtle",
										children: t.hijriHint
									}) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
									className: "flex flex-col gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
										className: "text-sm font-medium text-fg",
										children: t.dob
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-3 gap-2 sm:gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldSelect, {
												label: t.day,
												value: day,
												onChange: setDay,
												placeholder: t.selectDay,
												children: Array.from({ length: maxDay }, (_, i) => i + 1).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: n,
													children: formatNumber(n, lang)
												}, n))
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldSelect, {
												label: t.month,
												value: month,
												onChange: setMonth,
												placeholder: t.selectMonth,
												children: monthNames.map((name, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: index + 1,
													children: name
												}, name))
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldSelect, {
												label: t.year,
												value: year,
												onChange: setYear,
												placeholder: t.selectYear,
												children: Array.from({ length: years.max - years.min + 1 }, (_, i) => years.max - i).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: n,
													children: formatNumber(n, lang)
												}, n))
											})
										]
									})]
								}),
								error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-danger",
									role: "alert",
									children: error
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									size: "lg",
									className: "h-12 w-full rounded-md text-base",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, {
										className: "size-4",
										"aria-hidden": "true"
									}), t.calculate]
								})
							]
						})
					}),
					result && derived ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						ref: resultsRef,
						className: "flex flex-col gap-4",
						children: [
							derived.isToday ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "stagger-in flex items-start gap-3 rounded-2xl bg-biscuit px-5 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cake, {
									className: "mt-0.5 size-5 shrink-0 text-primary-fg",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold tracking-tight",
									children: t.happyBirthday
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm leading-normal text-muted",
									children: t.happyBirthdayBody
								})] })]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "stagger-in rounded-2xl bg-surface p-6 shadow-card",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-sm font-medium text-muted",
										children: t.yourAge
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-sm text-subtle",
										children: [
											t.bornOn,
											" ",
											formatYMD(result.birth, lang, result.calendar)
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-5 grid grid-cols-3 gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
												value: derived.age.years,
												label: t.years,
												lang
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
												value: derived.age.months,
												label: t.months,
												lang
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
												value: derived.age.days,
												label: t.days,
												lang
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-4 text-sm text-muted",
										children: [
											t.equivalent,
											": ",
											formatYMD(derived.equivalent, lang, derived.otherCal)
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "stagger-in rounded-2xl bg-surface p-6 shadow-card",
								"aria-live": "polite",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-medium text-muted",
									children: t.countdownTitle
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 grid grid-cols-5 gap-1.5 sm:gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											value: derived.count.months,
											label: t.months,
											lang,
											compact: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											value: derived.count.days,
											label: t.days,
											lang,
											compact: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											value: derived.count.hours,
											label: t.hours,
											lang,
											compact: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											value: derived.count.minutes,
											label: t.minutes,
											lang,
											compact: true
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											value: derived.count.seconds,
											label: t.seconds,
											lang,
											compact: true,
											live: true
										})
									]
								})]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 text-sm leading-normal text-subtle",
						children: t.emptyHint
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mx-auto max-w-2xl px-4 pb-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs leading-normal text-subtle",
					children: t.footer
				})
			})
		]
	});
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-9 shrink-0",
		"aria-hidden": "true",
		focusable: "false",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "10",
			className: "fill-biscuit"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M18.4 8.4a8.2 8.2 0 1 0 .2 15.3 9.8 9.8 0 0 1-.2-15.3z",
			className: "fill-primary-fg"
		})]
	});
}
function LanguageToggle({ lang, t, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex rounded-lg bg-surface-warm p-1",
		role: "group",
		"aria-label": t.language,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange("ar"),
			"aria-pressed": lang === "ar",
			className: cn("h-9 min-w-11 rounded-md px-3 text-sm font-medium transition-[background-color,box-shadow,color] duration-150 ease-out", lang === "ar" ? "bg-surface text-fg shadow-card" : "text-muted hover:text-fg"),
			children: t.langAr
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange("en"),
			"aria-pressed": lang === "en",
			className: cn("h-9 min-w-11 rounded-md px-3 text-sm font-medium transition-[background-color,box-shadow,color] duration-150 ease-out", lang === "en" ? "bg-surface text-fg shadow-card" : "text-muted hover:text-fg"),
			children: t.langEn
		})]
	});
}
function CalendarTabs({ calendar, t, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 gap-1 rounded-lg bg-surface-warm p-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onChange("gregorian"),
			"aria-pressed": calendar === "gregorian",
			className: cn("inline-flex h-11 items-center justify-center gap-2 rounded-md px-3 text-sm font-medium transition-[background-color,box-shadow,color] duration-150 ease-out", calendar === "gregorian" ? "bg-surface text-fg shadow-card" : "text-muted hover:text-fg"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {
				className: "size-4",
				"aria-hidden": "true"
			}), t.gregorian]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onChange("hijri"),
			"aria-pressed": calendar === "hijri",
			className: cn("inline-flex h-11 items-center justify-center gap-2 rounded-md px-3 text-sm font-medium transition-[background-color,box-shadow,color] duration-150 ease-out", calendar === "hijri" ? "bg-surface text-fg shadow-card" : "text-muted hover:text-fg"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
				className: "size-4",
				"aria-hidden": "true"
			}), t.hijri]
		})]
	});
}
function FieldSelect({ label, value, onChange, placeholder, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-w-0 flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "relative block",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				value: value || "",
				onChange: (event) => onChange(Number(event.target.value)),
				className: "h-12 w-full appearance-none rounded-md border-0 bg-surface-warm pe-9 ps-3 text-sm text-fg shadow-card outline-none transition-[box-shadow] duration-150 ease-out focus-visible:shadow-focus",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: placeholder
				}), children]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
				className: "pointer-events-none absolute top-1/2 end-3 size-4 -translate-y-1/2 text-muted",
				"aria-hidden": "true"
			})]
		})]
	});
}
function TodayChip({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "inline-flex max-w-full flex-wrap items-baseline gap-x-2 rounded-md bg-biscuit px-3 py-2 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium text-fg",
			children: value
		})]
	});
}
function Stat({ value, label, lang, compact = false, live = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex flex-col items-center justify-center rounded-md bg-surface-warm text-center", compact ? "px-1 py-3" : "px-2 py-5"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("font-semibold tabular-nums tracking-tight text-fg", compact ? "text-xl sm:text-2xl" : "text-3xl sm:text-4xl", live && "text-primary-fg"),
			children: formatNumber(value, lang)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 text-xs font-medium text-muted",
			children: label
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgeCalculator, {});
}
//#endregion
export { Home as component };
