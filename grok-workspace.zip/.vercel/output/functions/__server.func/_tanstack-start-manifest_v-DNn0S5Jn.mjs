//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DNn0S5Jn.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-xNC1Ozz-.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-xNC1Ozz-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Fy5bXHqS.js"]
	}
} });
//#endregion
export { tsrStartManifest };
