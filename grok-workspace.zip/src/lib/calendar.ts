import { addMonths } from "date-fns";
import {
  type CalendarSystem,
  type Lang,
  formatNumber,
  GREGORIAN_MONTHS,
  HIJRI_MONTHS,
} from "./i18n";

export type YMD = { year: number; month: number; day: number };

const HIJRI_MIN_YEAR = 1343;
const HIJRI_MAX_YEAR = 1500;

function utcNoon(year: number, month: number, day: number): Date {
  return new Date(Date.UTC(year, month - 1, day, 12, 0, 0));
}

function utcYMD(date: Date): YMD {
  return {
    year: date.getUTCFullYear(),
    month: date.getUTCMonth() + 1,
    day: date.getUTCDate(),
  };
}

function hijriPartsFromDate(date: Date): YMD {
  const parts = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura", {
    year: "numeric",
    month: "numeric",
    day: "numeric",
    timeZone: "UTC",
  }).formatToParts(date);

  const num = (type: Intl.DateTimeFormatPartTypes) => {
    const raw = parts.find((p) => p.type === type)?.value ?? "0";
    return Number.parseInt(raw.replace(/[^\d]/g, ""), 10) || 0;
  };

  return { year: num("year"), month: num("month"), day: num("day") };
}

export function gregorianToHijri(g: YMD): YMD {
  return hijriPartsFromDate(utcNoon(g.year, g.month, g.day));
}

export function hijriToGregorian(h: YMD): YMD {
  const estimateDays =
    Math.floor((h.year - 1) * 354.36708) +
    Math.floor((h.month - 1) * 29.530588) +
    (h.day - 1);

  let date = new Date(Date.UTC(622, 6, 19, 12, 0, 0) + estimateDays * 86_400_000);

  for (let i = 0; i < 16; i++) {
    const current = hijriPartsFromDate(date);
    const delta =
      (h.year - current.year) * 354 +
      (h.month - current.month) * 29 +
      (h.day - current.day);
    if (delta === 0) return utcYMD(date);
    date = new Date(date.getTime() + delta * 86_400_000);
  }

  return utcYMD(date);
}

export function isValidGregorian(g: YMD): boolean {
  if (g.month < 1 || g.month > 12 || g.day < 1 || g.day > 31) return false;
  const dt = new Date(g.year, g.month - 1, g.day);
  return (
    dt.getFullYear() === g.year &&
    dt.getMonth() === g.month - 1 &&
    dt.getDate() === g.day
  );
}

export function isValidHijri(h: YMD): boolean {
  if (h.year < HIJRI_MIN_YEAR || h.year > HIJRI_MAX_YEAR) return false;
  if (h.month < 1 || h.month > 12 || h.day < 1 || h.day > 30) return false;
  const g = hijriToGregorian(h);
  const back = gregorianToHijri(g);
  return back.year === h.year && back.month === h.month && back.day === h.day;
}

export function gregorianDaysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

export function hijriDaysInMonth(year: number, month: number): number {
  const start = hijriToGregorian({ year, month, day: 1 });
  const startDate = utcNoon(start.year, start.month, start.day);
  const probe = new Date(startDate.getTime() + 29 * 86_400_000);
  const h = hijriPartsFromDate(probe);
  return h.year === year && h.month === month ? 30 : 29;
}

export function daysInMonth(
  calendar: CalendarSystem,
  year: number,
  month: number,
): number {
  if (!year || !month) return 31;
  return calendar === "hijri"
    ? hijriDaysInMonth(year, month)
    : gregorianDaysInMonth(year, month);
}

export function localYMD(date: Date): YMD {
  return {
    year: date.getFullYear(),
    month: date.getMonth() + 1,
    day: date.getDate(),
  };
}

export function ymdToLocalDate(ymd: YMD, hours = 0, minutes = 0, seconds = 0): Date {
  return new Date(ymd.year, ymd.month - 1, ymd.day, hours, minutes, seconds);
}

export function compareYMD(a: YMD, b: YMD): number {
  return a.year - b.year || a.month - b.month || a.day - b.day;
}

export function calendarDiff(
  birth: YMD,
  now: YMD,
  monthLength: (year: number, month: number) => number,
): { years: number; months: number; days: number } {
  let years = now.year - birth.year;
  let months = now.month - birth.month;
  let days = now.day - birth.day;

  if (days < 0) {
    months -= 1;
    const prevMonth = now.month === 1 ? 12 : now.month - 1;
    const prevYear = now.month === 1 ? now.year - 1 : now.year;
    days += monthLength(prevYear, prevMonth);
  }

  if (months < 0) {
    years -= 1;
    months += 12;
  }

  return { years: Math.max(0, years), months: Math.max(0, months), days: Math.max(0, days) };
}

export function convertYMD(
  ymd: YMD,
  from: CalendarSystem,
  to: CalendarSystem,
): YMD {
  if (from === to) return ymd;
  return from === "gregorian" ? gregorianToHijri(ymd) : hijriToGregorian(ymd);
}

export function yearRange(calendar: CalendarSystem, today: Date): { min: number; max: number } {
  if (calendar === "hijri") {
    const todayH = gregorianToHijri(localYMD(today));
    return { min: HIJRI_MIN_YEAR, max: todayH.year };
  }
  return { min: 1925, max: today.getFullYear() };
}

export function formatYMD(ymd: YMD, lang: Lang, calendar: CalendarSystem): string {
  const months = calendar === "hijri" ? HIJRI_MONTHS[lang] : GREGORIAN_MONTHS[lang];
  const monthName = months[ymd.month - 1] ?? "";
  const day = formatNumber(ymd.day, lang);
  const year = formatNumber(ymd.year, lang);
  const suffix = calendar === "hijri" ? (lang === "ar" ? " هـ" : " AH") : "";
  return `${day} ${monthName} ${year}${suffix}`;
}

export function nextBirthdayYMD(
  birth: YMD,
  today: YMD,
  calendar: CalendarSystem,
): { next: YMD; isToday: boolean } {
  const monthLength =
    calendar === "hijri" ? hijriDaysInMonth : gregorianDaysInMonth;

  const clampedDay = Math.min(birth.day, monthLength(today.year, birth.month));
  let candidate: YMD = { year: today.year, month: birth.month, day: clampedDay };

  if (compareYMD(candidate, today) < 0) {
    const year = today.year + 1;
    candidate = {
      year,
      month: birth.month,
      day: Math.min(birth.day, monthLength(year, birth.month)),
    };
  }

  return {
    next: candidate,
    isToday: candidate.year === today.year && compareYMD(candidate, today) === 0,
  };
}

export function nextBirthdayDate(
  birth: YMD,
  now: Date,
  calendar: CalendarSystem,
): { target: Date; isToday: boolean } {
  const todayGregorian = localYMD(now);
  const today =
    calendar === "hijri" ? gregorianToHijri(todayGregorian) : todayGregorian;
  const { next, isToday } = nextBirthdayYMD(birth, today, calendar);
  const gregorianNext =
    calendar === "hijri" ? hijriToGregorian(next) : next;

  let target = ymdToLocalDate(gregorianNext, 0, 0, 0);

  if (isToday) {
    const followingYear = { ...next, year: next.year + 1 };
    const monthLength =
      calendar === "hijri" ? hijriDaysInMonth : gregorianDaysInMonth;
    followingYear.day = Math.min(
      birth.day,
      monthLength(followingYear.year, followingYear.month),
    );
    const g =
      calendar === "hijri" ? hijriToGregorian(followingYear) : followingYear;
    target = ymdToLocalDate(g, 0, 0, 0);
  }

  return { target, isToday };
}

export function countdownParts(
  now: Date,
  target: Date,
): {
  months: number;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
} {
  if (target.getTime() <= now.getTime()) {
    return { months: 0, days: 0, hours: 0, minutes: 0, seconds: 0 };
  }

  let months = 0;
  let cursor = now;

  while (true) {
    const probe = addMonths(cursor, 1);
    if (probe.getTime() <= target.getTime()) {
      months += 1;
      cursor = probe;
    } else {
      break;
    }
    if (months > 24) break;
  }

  let remaining = Math.max(0, target.getTime() - cursor.getTime());
  const days = Math.floor(remaining / 86_400_000);
  remaining -= days * 86_400_000;
  const hours = Math.floor(remaining / 3_600_000);
  remaining -= hours * 3_600_000;
  const minutes = Math.floor(remaining / 60_000);
  remaining -= minutes * 60_000;
  const seconds = Math.floor(remaining / 1000);

  return { months, days, hours, minutes, seconds };
}

export function supportsUmmAlQura(): boolean {
  try {
    const cal = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura", {
      year: "numeric",
    }).resolvedOptions().calendar;
    return cal === "islamic-umalqura";
  } catch {
    return false;
  }
}
