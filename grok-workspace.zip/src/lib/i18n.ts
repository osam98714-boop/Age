export type Lang = "ar" | "en";
export type CalendarSystem = "gregorian" | "hijri";

export const translations = {
  en: {
    appName: "Age",
    appNameFull: "Age Calculator",
    kicker: "Age & birthday",
    title: "Your age, to the day.",
    tagline:
      "Measure years in the Gregorian or Hijri calendar, then watch a live countdown to your next birthday.",
    today: "Today",
    language: "Language",
    langAr: "العربية",
    langEn: "EN",
    gregorian: "Gregorian",
    hijri: "Hijri",
    hijriHint: "Umm al-Qura calendar",
    dob: "Date of birth",
    day: "Day",
    month: "Month",
    year: "Year",
    calculate: "Calculate age",
    yourAge: "Your age",
    years: "Years",
    months: "Months",
    days: "Days",
    hours: "Hours",
    minutes: "Minutes",
    seconds: "Seconds",
    countdownTitle: "Until your next birthday",
    happyBirthday: "Happy birthday",
    happyBirthdayBody: "Today is yours. The next year starts counting from midnight.",
    equivalent: "In the other calendar",
    bornOn: "Born on",
    emptyHint:
      "Choose a calendar, enter your date of birth, and see your exact age with a ticking countdown.",
    errorFuture: "Date of birth cannot be in the future.",
    errorInvalid: "This date does not exist in the selected calendar.",
    errorIncomplete: "Please choose day, month, and year.",
    footer: "Hijri dates follow the Umm al-Qura calendar used in Saudi Arabia.",
    switchTo: "Switch language",
    selectDay: "Day",
    selectMonth: "Month",
    selectYear: "Year",
  },
  ar: {
    appName: "العمر",
    appNameFull: "حاسبة العمر",
    kicker: "العمر وعيد الميلاد",
    title: "عمرك، إلى اليوم.",
    tagline:
      "احسب عمرك بالميلادي أو الهجري وفق تقويم أم القرى، وتابع العد التنازلي الحيّ حتى عيد ميلادك القادم.",
    today: "اليوم",
    language: "اللغة",
    langAr: "العربية",
    langEn: "EN",
    gregorian: "ميلادي",
    hijri: "هجري",
    hijriHint: "تقويم أم القرى",
    dob: "تاريخ الميلاد",
    day: "اليوم",
    month: "الشهر",
    year: "السنة",
    calculate: "احسب العمر",
    yourAge: "عمرك",
    years: "سنوات",
    months: "أشهر",
    days: "أيام",
    hours: "ساعات",
    minutes: "دقائق",
    seconds: "ثوانٍ",
    countdownTitle: "حتى عيد ميلادك القادم",
    happyBirthday: "عيد ميلاد سعيد",
    happyBirthdayBody: "اليوم يومك. يبدأ العد للسنة القادمة من منتصف الليل.",
    equivalent: "في التقويم الآخر",
    bornOn: "وُلدت في",
    emptyHint:
      "اختر التقويم، أدخل تاريخ ميلادك، واطّلع على عمرك بدقة مع عدّ تنازلي يتحرّك كل ثانية.",
    errorFuture: "لا يمكن أن يكون تاريخ الميلاد في المستقبل.",
    errorInvalid: "هذا التاريخ غير موجود في التقويم المختار.",
    errorIncomplete: "يرجى اختيار اليوم والشهر والسنة.",
    footer: "التواريخ الهجرية وفق تقويم أم القرى المعتمد في المملكة العربية السعودية.",
    switchTo: "تبديل اللغة",
    selectDay: "اليوم",
    selectMonth: "الشهر",
    selectYear: "السنة",
  },
} as const;

export type TranslationKey = keyof typeof translations.en;

export const GREGORIAN_MONTHS = {
  en: [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ],
  ar: [
    "يناير",
    "فبراير",
    "مارس",
    "أبريل",
    "مايو",
    "يونيو",
    "يوليو",
    "أغسطس",
    "سبتمبر",
    "أكتوبر",
    "نوفمبر",
    "ديسمبر",
  ],
} as const;

export const HIJRI_MONTHS = {
  en: [
    "Muharram",
    "Safar",
    "Rabiʿ al-Awwal",
    "Rabiʿ al-Thani",
    "Jumada al-Ula",
    "Jumada al-Thania",
    "Rajab",
    "Shaʿban",
    "Ramadan",
    "Shawwal",
    "Dhu al-Qaʿdah",
    "Dhu al-Hijjah",
  ],
  ar: [
    "محرم",
    "صفر",
    "ربيع الأول",
    "ربيع الآخر",
    "جمادى الأولى",
    "جمادى الآخرة",
    "رجب",
    "شعبان",
    "رمضان",
    "شوال",
    "ذو القعدة",
    "ذو الحجة",
  ],
} as const;

const ARABIC_DIGITS = ["٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"];

export function formatNumber(n: number, lang: Lang): string {
  const s = String(Math.trunc(n));
  if (lang !== "ar") return s;
  return s.replace(/\d/g, (d) => ARABIC_DIGITS[Number(d)] ?? d);
}

export const LANG_STORAGE_KEY = "age-calc-lang";
