import { createFileRoute } from "@tanstack/react-router";
import { AgeCalculator } from "@/components/age-calculator";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AgeCalculator />;
}
