import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { Cake, CalendarDays, ChevronDown, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  calendarDiff,
  compareYMD,
  convertYMD,
  countdownParts,
  daysInMonth,
  formatYMD,
  gregorianDaysInMonth,
  gregorianToHijri,
  hijriDaysInMonth,
  isValidGregorian,
  isValidHijri,
  localYMD,
  nextBirthdayDate,
  yearRange,
  type YMD,
} from "@/lib/calendar";
import {
  GREGORIAN_MONTHS,
  HIJRI_MONTHS,
  LANG_STORAGE_KEY,
  formatNumber,
  translations,
  type CalendarSystem,
  type Lang,
} from "@/lib/i18n";
import { cn } from "@/lib/utils";

type Result = {
  birth: YMD;
  calendar: CalendarSystem;
};

function readStoredLang(): Lang {
  if (typeof window === "undefined") return "ar";
  const stored = window.localStorage.getItem(LANG_STORAGE_KEY);
  return stored === "en" || stored === "ar" ? stored : "ar";
}

export function AgeCalculator() {
  const [lang, setLang] = useState<Lang>("ar");
  const [calendar, setCalendar] = useState<CalendarSystem>("gregorian");
  const [day, setDay] = useState(0);
  const [month, setMonth] = useState(0);
  const [year, setYear] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const [now, setNow] = useState<Date | null>(null);
  const resultsRef = useRef<HTMLDivElement>(null);
  const shouldScroll = useRef(false);

  const t = translations[lang];

  useEffect(() => {
    const stored = readStoredLang();
    if (stored !== lang) setLang(stored);
    // Persist only after the stored preference has been applied.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    document.title = t.appNameFull;
  }, [lang, t.appNameFull]);

  useEffect(() => {
    const tick = () => setNow(new Date());
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  const todayG = now ? localYMD(now) : null;
  const todayH = todayG ? gregorianToHijri(todayG) : null;
  const years = now ? yearRange(calendar, now) : { min: 1925, max: 2026 };
  const monthNames = calendar === "hijri" ? HIJRI_MONTHS[lang] : GREGORIAN_MONTHS[lang];
  const maxDay = daysInMonth(calendar, year, month);

  useEffect(() => {
    if (day && month && year && day > maxDay) setDay(maxDay);
  }, [day, month, year, maxDay]);

  useEffect(() => {
    if (!shouldScroll.current || !resultsRef.current) return;
    shouldScroll.current = false;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    resultsRef.current.scrollIntoView({
      behavior: reduce ? "auto" : "smooth",
      block: "start",
    });
  }, [result]);

  const derived = useMemo(() => {
    if (!result || !now) return null;
    const todayGregorian = localYMD(now);
    const todayInCal =
      result.calendar === "hijri"
        ? gregorianToHijri(todayGregorian)
        : todayGregorian;
    const monthLength =
      result.calendar === "hijri" ? hijriDaysInMonth : gregorianDaysInMonth;
    const age = calendarDiff(result.birth, todayInCal, monthLength);
    const otherCal: CalendarSystem =
      result.calendar === "hijri" ? "gregorian" : "hijri";
    const equivalent = convertYMD(result.birth, result.calendar, otherCal);
    const { target, isToday } = nextBirthdayDate(result.birth, now, result.calendar);
    const count = countdownParts(now, target);
    return { age, equivalent, otherCal, isToday, count };
  }, [result, now]);

  function switchCalendar(next: CalendarSystem) {
    if (next === calendar) return;
    if (day && month && year) {
      const converted = convertYMD({ year, month, day }, calendar, next);
      setYear(converted.year);
      setMonth(converted.month);
      setDay(converted.day);
      if (result) {
        setResult({ birth: converted, calendar: next });
      }
    } else if (result) {
      const converted = convertYMD(result.birth, result.calendar, next);
      setResult({ birth: converted, calendar: next });
    }
    setCalendar(next);
    setError(null);
  }

  function handleCalculate(event: FormEvent) {
    event.preventDefault();
    if (!day || !month || !year) {
      setError(t.errorIncomplete);
      return;
    }
    const birth: YMD = { year, month, day };
    const valid =
      calendar === "hijri" ? isValidHijri(birth) : isValidGregorian(birth);
    if (!valid) {
      setError(t.errorInvalid);
      return;
    }
    const nowDate = now ?? new Date();
    const todayGregorian = localYMD(nowDate);
    const todayInCal =
      calendar === "hijri" ? gregorianToHijri(todayGregorian) : todayGregorian;
    if (compareYMD(birth, todayInCal) > 0) {
      setError(t.errorFuture);
      return;
    }
    setError(null);
    shouldScroll.current = true;
    setResult({ birth, calendar });
  }

  return (
    <div className="relative min-h-dvh bg-bg text-fg">
      <div className="h-1 bg-biscuit-deep" />
      <header className="sticky top-0 z-20 bg-bg">
        <div className="mx-auto flex h-16 max-w-2xl items-center justify-between px-4">
          <div className="flex items-center gap-2.5">
            <Mark />
            <div className="leading-tight">
              <p className="text-sm font-semibold tracking-tight">{t.appName}</p>
              <p className="text-xs text-muted">{t.appNameFull}</p>
            </div>
          </div>
          <LanguageToggle
            lang={lang}
            t={t}
            onChange={(next) => {
              setLang(next);
              window.localStorage.setItem(LANG_STORAGE_KEY, next);
            }}
          />
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-2xl flex-col gap-6 px-4 pb-16 pt-8 sm:pt-12">
        <section className="flex flex-col gap-4">
          <p className="text-xs font-medium tracking-widest text-muted">
            {t.kicker}
          </p>
          <h1 className="max-w-xl text-4xl font-semibold leading-tight tracking-tight sm:text-5xl">
            {t.title}
          </h1>
          <p className="max-w-lg text-base leading-normal text-muted">{t.tagline}</p>
          {todayG && todayH ? (
            <div className="flex flex-wrap gap-2 pt-1">
              <TodayChip
                label={t.gregorian}
                value={formatYMD(todayG, lang, "gregorian")}
              />
              <TodayChip
                label={t.hijri}
                value={formatYMD(todayH, lang, "hijri")}
              />
            </div>
          ) : (
            <div className="h-9 w-64 rounded-md bg-surface-warm" />
          )}
        </section>

        <section className="rounded-2xl bg-surface p-6 shadow-card">
          <form className="flex flex-col gap-5" onSubmit={handleCalculate}>
            <div className="flex flex-col gap-2">
              <CalendarTabs
                calendar={calendar}
                t={t}
                onChange={switchCalendar}
              />
              {calendar === "hijri" ? (
                <p className="px-1 text-xs text-subtle">{t.hijriHint}</p>
              ) : null}
            </div>

            <fieldset className="flex flex-col gap-3">
              <legend className="text-sm font-medium text-fg">{t.dob}</legend>
              <div className="grid grid-cols-3 gap-2 sm:gap-3">
                <FieldSelect
                  label={t.day}
                  value={day}
                  onChange={setDay}
                  placeholder={t.selectDay}
                >
                  {Array.from({ length: maxDay }, (_, i) => i + 1).map((n) => (
                    <option key={n} value={n}>
                      {formatNumber(n, lang)}
                    </option>
                  ))}
                </FieldSelect>
                <FieldSelect
                  label={t.month}
                  value={month}
                  onChange={setMonth}
                  placeholder={t.selectMonth}
                >
                  {monthNames.map((name, index) => (
                    <option key={name} value={index + 1}>
                      {name}
                    </option>
                  ))}
                </FieldSelect>
                <FieldSelect
                  label={t.year}
                  value={year}
                  onChange={setYear}
                  placeholder={t.selectYear}
                >
                  {Array.from(
                    { length: years.max - years.min + 1 },
                    (_, i) => years.max - i,
                  ).map((n) => (
                    <option key={n} value={n}>
                      {formatNumber(n, lang)}
                    </option>
                  ))}
                </FieldSelect>
              </div>
            </fieldset>

            {error ? (
              <p className="text-sm font-medium text-danger" role="alert">
                {error}
              </p>
            ) : null}

            <Button type="submit" size="lg" className="h-12 w-full rounded-md text-base">
              <CalendarDays className="size-4" aria-hidden="true" />
              {t.calculate}
            </Button>
          </form>
        </section>

        {result && derived ? (
          <div ref={resultsRef} className="flex flex-col gap-4">
            {derived.isToday ? (
              <div className="stagger-in flex items-start gap-3 rounded-2xl bg-biscuit px-5 py-4">
                <Cake className="mt-0.5 size-5 shrink-0 text-primary-fg" aria-hidden="true" />
                <div>
                  <p className="font-semibold tracking-tight">{t.happyBirthday}</p>
                  <p className="mt-1 text-sm leading-normal text-muted">
                    {t.happyBirthdayBody}
                  </p>
                </div>
              </div>
            ) : null}

            <section className="stagger-in rounded-2xl bg-surface p-6 shadow-card">
              <h2 className="text-sm font-medium text-muted">{t.yourAge}</h2>
              <p className="mt-1 text-sm text-subtle">
                {t.bornOn}{" "}
                {formatYMD(result.birth, lang, result.calendar)}
              </p>
              <div className="mt-5 grid grid-cols-3 gap-2">
                <Stat value={derived.age.years} label={t.years} lang={lang} />
                <Stat value={derived.age.months} label={t.months} lang={lang} />
                <Stat value={derived.age.days} label={t.days} lang={lang} />
              </div>
              <p className="mt-4 text-sm text-muted">
                {t.equivalent}: {formatYMD(derived.equivalent, lang, derived.otherCal)}
              </p>
            </section>

            <section
              className="stagger-in rounded-2xl bg-surface p-6 shadow-card"
              aria-live="polite"
            >
              <h2 className="text-sm font-medium text-muted">{t.countdownTitle}</h2>
              <div className="mt-5 grid grid-cols-5 gap-1.5 sm:gap-2">
                <Stat value={derived.count.months} label={t.months} lang={lang} compact />
                <Stat value={derived.count.days} label={t.days} lang={lang} compact />
                <Stat value={derived.count.hours} label={t.hours} lang={lang} compact />
                <Stat value={derived.count.minutes} label={t.minutes} lang={lang} compact />
                <Stat value={derived.count.seconds} label={t.seconds} lang={lang} compact live />
              </div>
            </section>
          </div>
        ) : (
          <p className="px-1 text-sm leading-normal text-subtle">{t.emptyHint}</p>
        )}
      </main>

      <footer className="mx-auto max-w-2xl px-4 pb-10">
        <p className="text-xs leading-normal text-subtle">{t.footer}</p>
      </footer>
    </div>
  );
}

function Mark() {
  return (
    <svg
      viewBox="0 0 32 32"
      className="size-9 shrink-0"
      aria-hidden="true"
      focusable="false"
    >
      <rect width="32" height="32" rx="10" className="fill-biscuit" />
      <path
        d="M18.4 8.4a8.2 8.2 0 1 0 .2 15.3 9.8 9.8 0 0 1-.2-15.3z"
        className="fill-primary-fg"
      />
    </svg>
  );
}

function LanguageToggle({
  lang,
  t,
  onChange,
}: {
  lang: Lang;
  t: (typeof translations)[Lang];
  onChange: (lang: Lang) => void;
}) {
  return (
    <div
      className="flex rounded-lg bg-surface-warm p-1"
      role="group"
      aria-label={t.language}
    >
      <button
        type="button"
        onClick={() => onChange("ar")}
        aria-pressed={lang === "ar"}
        className={cn(
          "h-9 min-w-11 rounded-md px-3 text-sm font-medium transition-[background-color,box-shadow,color] duration-150 ease-out",
          lang === "ar"
            ? "bg-surface text-fg shadow-card"
            : "text-muted hover:text-fg",
        )}
      >
        {t.langAr}
      </button>
      <button
        type="button"
        onClick={() => onChange("en")}
        aria-pressed={lang === "en"}
        className={cn(
          "h-9 min-w-11 rounded-md px-3 text-sm font-medium transition-[background-color,box-shadow,color] duration-150 ease-out",
          lang === "en"
            ? "bg-surface text-fg shadow-card"
            : "text-muted hover:text-fg",
        )}
      >
        {t.langEn}
      </button>
    </div>
  );
}

function CalendarTabs({
  calendar,
  t,
  onChange,
}: {
  calendar: CalendarSystem;
  t: (typeof translations)[Lang];
  onChange: (calendar: CalendarSystem) => void;
}) {
  return (
    <div className="grid grid-cols-2 gap-1 rounded-lg bg-surface-warm p-1">
      <button
        type="button"
        onClick={() => onChange("gregorian")}
        aria-pressed={calendar === "gregorian"}
        className={cn(
          "inline-flex h-11 items-center justify-center gap-2 rounded-md px-3 text-sm font-medium transition-[background-color,box-shadow,color] duration-150 ease-out",
          calendar === "gregorian"
            ? "bg-surface text-fg shadow-card"
            : "text-muted hover:text-fg",
        )}
      >
        <Sun className="size-4" aria-hidden="true" />
        {t.gregorian}
      </button>
      <button
        type="button"
        onClick={() => onChange("hijri")}
        aria-pressed={calendar === "hijri"}
        className={cn(
          "inline-flex h-11 items-center justify-center gap-2 rounded-md px-3 text-sm font-medium transition-[background-color,box-shadow,color] duration-150 ease-out",
          calendar === "hijri"
            ? "bg-surface text-fg shadow-card"
            : "text-muted hover:text-fg",
        )}
      >
        <Moon className="size-4" aria-hidden="true" />
        {t.hijri}
      </button>
    </div>
  );
}

function FieldSelect({
  label,
  value,
  onChange,
  placeholder,
  children,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  placeholder: string;
  children: ReactNode;
}) {
  return (
    <label className="flex min-w-0 flex-col gap-2">
      <span className="text-xs font-medium text-muted">{label}</span>
      <span className="relative block">
        <select
          value={value || ""}
          onChange={(event) => onChange(Number(event.target.value))}
          className="h-12 w-full appearance-none rounded-md border-0 bg-surface-warm pe-9 ps-3 text-sm text-fg shadow-card outline-none transition-[box-shadow] duration-150 ease-out focus-visible:shadow-focus"
        >
          <option value="">{placeholder}</option>
          {children}
        </select>
        <ChevronDown
          className="pointer-events-none absolute top-1/2 end-3 size-4 -translate-y-1/2 text-muted"
          aria-hidden="true"
        />
      </span>
    </label>
  );
}

function TodayChip({ label, value }: { label: string; value: string }) {
  return (
    <p className="inline-flex max-w-full flex-wrap items-baseline gap-x-2 rounded-md bg-biscuit px-3 py-2 text-sm">
      <span className="text-xs font-medium text-muted">{label}</span>
      <span className="font-medium text-fg">{value}</span>
    </p>
  );
}

function Stat({
  value,
  label,
  lang,
  compact = false,
  live = false,
}: {
  value: number;
  label: string;
  lang: Lang;
  compact?: boolean;
  live?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center rounded-md bg-surface-warm text-center",
        compact ? "px-1 py-3" : "px-2 py-5",
      )}
    >
      <span
        className={cn(
          "font-semibold tabular-nums tracking-tight text-fg",
          compact ? "text-xl sm:text-2xl" : "text-3xl sm:text-4xl",
          live && "text-primary-fg",
        )}
      >
        {formatNumber(value, lang)}
      </span>
      <span className="mt-1 text-xs font-medium text-muted">
        {label}
      </span>
    </div>
  );
}
